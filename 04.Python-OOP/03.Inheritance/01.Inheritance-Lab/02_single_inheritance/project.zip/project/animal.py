class Animal:

    def eat(self) -> str:
        return "eating..."
