class Vehicle:

    def move(self) -> str:
        return "moving..."
